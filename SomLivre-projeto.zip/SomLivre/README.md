# Som Livre — projeto Android

Player local para Android com tema escuro, busca na biblioteca, seleção de vários arquivos de áudio, reprodução, anterior/próxima faixa e favoritos. Não usa conta, assinatura ou internet para tocar arquivos locais.

## Como gerar o APK

1. Instale o **Android Studio** em https://developer.android.com/studio
2. Extraia esta pasta e abra `SomLivre` no Android Studio (**Open**).
3. Quando o Android Studio pedir, instale o Android SDK Platform 35 e aceite a sincronização do Gradle.
4. Aguarde o Gradle terminar de sincronizar. Se pedir um JDK, selecione o JDK 17 ou o JDK embutido no Android Studio.
5. No menu **Build**, escolha **Build APK(s)** (em algumas versões: **Build > Build Bundle(s) / APK(s) > Build APK(s)**).
6. O APK de depuração normalmente será criado em `app/build/outputs/apk/debug/app-debug.apk`.
7. Copie o APK para o celular e abra-o. Se solicitado, permita instalar aplicativos dessa fonte.

## Como usar

Abra o Som Livre, toque em **Adicionar músicas do celular**, selecione um ou vários arquivos de áudio e toque em uma faixa para reproduzir. Use a busca para filtrar a lista e o coração para marcar favoritos.

## Observações

- Este projeto é o código-fonte; o APK precisa ser compilado pelo Android Studio.
- A biblioteca selecionada fica em memória durante a sessão. Os favoritos são salvos no aparelho, mas a lista de músicas precisa ser selecionada novamente ao reabrir o app.
- Esta é uma versão inicial: ainda não tem reprodução em segundo plano com serviço de mídia, capas automáticas, playlists personalizadas ou leitura automática de toda a biblioteca.
