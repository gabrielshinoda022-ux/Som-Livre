package com.gabriel.somlivre

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import android.text.Editable
import android.text.TextWatcher
import java.util.Locale

class MainActivity : Activity() {
    private data class Track(val uri: Uri, val name: String, val artist: String)
    private val tracks = mutableListOf<Track>()
    private val favorites = mutableSetOf<String>()
    private var visibleTracks = listOf<Track>()
    private var player: MediaPlayer? = null
    private var current: Track? = null
    private var isPlaying = false
    private lateinit var list: LinearLayout
    private lateinit var nowTitle: TextView
    private lateinit var nowArtist: TextView
    private lateinit var playButton: Button
    private lateinit var search: EditText
    private lateinit var root: LinearLayout

    private val green = Color.rgb(30, 215, 96)
    private val background = Color.rgb(18, 18, 18)
    private val panel = Color.rgb(35, 35, 35)
    private val white = Color.WHITE
    private val muted = Color.rgb(180, 180, 180)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        favorites.addAll(getPreferences(MODE_PRIVATE).getStringSet("favorites", emptySet()) ?: emptySet())
        buildUi()
        renderTracks()
    }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(22), dp(18), dp(12))
            setBackgroundColor(background)
        }
        val header = TextView(this).apply {
            text = "som livre"
            textSize = 30f
            setTextColor(green)
            typeface = android.graphics.Typeface.create("sans-serif-black", android.graphics.Typeface.BOLD)
        }
        root.addView(header)
        root.addView(TextView(this).apply {
            text = "Sua música. Do seu jeito."
            textSize = 14f; setTextColor(muted)
            setPadding(0, dp(3), 0, dp(18))
        })
        val add = Button(this).apply {
            text = "+  Adicionar músicas do celular"
            setTextColor(Color.BLACK); setBackgroundTintList(android.content.res.ColorStateList.valueOf(green))
            setOnClickListener { chooseAudio() }
        }
        root.addView(add, matchWrap())
        search = EditText(this).apply {
            hint = "Buscar na biblioteca"
            setHintTextColor(muted); setTextColor(white); textSize = 15f
            setSingleLine(true)
            backgroundTintList = android.content.res.ColorStateList.valueOf(muted)
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { renderTracks() }
                override fun afterTextChanged(s: Editable?) {}
            })
        }
        root.addView(search, LinearLayout.LayoutParams(-1, dp(52)))
        root.addView(TextView(this).apply {
            text = "SUA BIBLIOTECA"
            textSize = 12f; setTextColor(muted)
            setPadding(0, dp(10), 0, dp(8))
        })
        val scroll = ScrollView(this)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val nowPlaying = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(10), dp(14), dp(8))
            setBackgroundColor(panel)
        }
        nowTitle = TextView(this).apply { text = "Nenhuma música selecionada"; textSize = 16f; setTextColor(white) }
        nowArtist = TextView(this).apply { text = "Adicione arquivos de áudio para começar"; textSize = 12f; setTextColor(muted) }
        nowPlaying.addView(nowTitle)
        nowPlaying.addView(nowArtist)
        val controls = LinearLayout(this).apply { gravity = Gravity.CENTER; orientation = LinearLayout.HORIZONTAL }
        val previous = Button(this).apply { text = "|◀"; setTextColor(white); setBackgroundColor(Color.TRANSPARENT); setOnClickListener { step(-1) } }
        playButton = Button(this).apply { text = "▶"; setTextColor(green); textSize = 20f; setBackgroundColor(Color.TRANSPARENT); setOnClickListener { togglePlayback() } }
        val next = Button(this).apply { text = "▶|"; setTextColor(white); setBackgroundColor(Color.TRANSPARENT); setOnClickListener { step(1) } }
        controls.addView(previous); controls.addView(playButton); controls.addView(next)
        nowPlaying.addView(controls)
        root.addView(nowPlaying, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))
        setContentView(root)
    }

    private fun chooseAudio() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "audio/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        }
        startActivityForResult(intent, 42)
    }

    @Deprecated("Deprecated by Android, retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 42 || resultCode != RESULT_OK || data == null) return
        val selected = mutableListOf<Uri>()
        data.clipData?.let { clip -> for (i in 0 until clip.itemCount) selected.add(clip.getItemAt(i).uri) }
        if (selected.isEmpty()) data.data?.let { selected.add(it) }
        selected.forEach { uri ->
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            if (tracks.none { it.uri == uri }) {
                val raw = queryName(uri)
                tracks.add(Track(uri, raw.substringBeforeLast('.', raw), "Arquivo local"))
            }
        }
        renderTracks()
        if (tracks.isNotEmpty() && current == null) playTrack(tracks.first())
    }

    private fun queryName(uri: Uri): String {
        var name = uri.lastPathSegment ?: "Música"
        try {
            contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) name = c.getString(0) ?: name
            }
        } catch (_: Exception) {}
        return name
    }

    private fun renderTracks() {
        if (!::list.isInitialized) return
        list.removeAllViews()
        val q = if (::search.isInitialized) search.text.toString().trim().lowercase(Locale.getDefault()) else ""
        visibleTracks = tracks.filter { it.name.lowercase(Locale.getDefault()).contains(q) }
        if (visibleTracks.isEmpty()) {
            list.addView(TextView(this).apply {
                text = if (tracks.isEmpty()) "Sua biblioteca está vazia.\nToque em ‘Adicionar músicas’ para escolher MP3 e outros áudios." else "Nenhuma música encontrada."
                textSize = 14f; setTextColor(muted); gravity = Gravity.CENTER
                setPadding(dp(20), dp(36), dp(20), dp(36))
            })
        }
        visibleTracks.forEach { track ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(10), dp(8), dp(4), dp(8)); setBackgroundColor(if (track == current) panel else background)
            }
            val labels = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            labels.addView(TextView(this).apply { text = track.name; textSize = 15f; setTextColor(if (track == current) green else white); maxLines = 1 })
            labels.addView(TextView(this).apply { text = track.artist; textSize = 12f; setTextColor(muted) })
            row.addView(labels, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            val fav = Button(this).apply {
                text = if (favorites.contains(track.uri.toString())) "♥" else "♡"
                setTextColor(if (favorites.contains(track.uri.toString())) green else muted)
                setBackgroundColor(Color.TRANSPARENT)
                setOnClickListener {
                    val key = track.uri.toString()
                    if (!favorites.add(key)) favorites.remove(key)
                    getPreferences(MODE_PRIVATE).edit().putStringSet("favorites", favorites.toSet()).apply()
                    renderTracks()
                }
            }
            row.addView(fav)
            row.setOnClickListener { playTrack(track) }
            list.addView(row, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))
            val divider = View(this).apply { setBackgroundColor(Color.rgb(48, 48, 48)) }
            list.addView(divider, LinearLayout.LayoutParams(-1, dp(1)))
        }
    }

    private fun playTrack(track: Track) {
        try {
            player?.release()
            player = MediaPlayer().apply {
                setDataSource(this@MainActivity, track.uri)
                setOnPreparedListener { mp -> mp.start(); isPlaying = true; playButton.text = "Ⅱ"; updateNowPlaying(track); renderTracks() }
                setOnCompletionListener { step(1) }
                setOnErrorListener { _, _, _ -> isPlaying = false; playButton.text = "▶"; Toast.makeText(this@MainActivity, "Não foi possível reproduzir este arquivo.", Toast.LENGTH_SHORT).show(); true }
                prepareAsync()
            }
            current = track
            isPlaying = false
            nowTitle.text = track.name
            nowArtist.text = "Carregando…"
            playButton.text = "…"
            renderTracks()
        } catch (_: Exception) {
            Toast.makeText(this, "Não foi possível abrir essa música.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun updateNowPlaying(track: Track) {
        nowTitle.text = track.name
        nowArtist.text = "Arquivo local • Som Livre"
    }

    private fun togglePlayback() {
        val p = player
        if (p == null) {
            if (tracks.isNotEmpty()) playTrack(tracks.first()) else chooseAudio()
            return
        }
        try {
            if (p.isPlaying) { p.pause(); isPlaying = false; playButton.text = "▶" }
            else { p.start(); isPlaying = true; playButton.text = "Ⅱ" }
        } catch (_: Exception) { current?.let { playTrack(it) } }
    }

    private fun step(direction: Int) {
        if (tracks.isEmpty()) return
        val index = tracks.indexOfFirst { it == current }.let { if (it < 0) 0 else it }
        val nextIndex = (index + direction + tracks.size) % tracks.size
        playTrack(tracks[nextIndex])
    }

    override fun onDestroy() {
        player?.release(); player = null
        super.onDestroy()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
    private fun matchWrap() = LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT)
}
